Team Banana Phase 4
IU Committee project

Team Banana is:
Justin Ashdown
Eric Grounds
Joel Haubold
Jared Short
Dung Truong

Project is for C308 Fall 2012. Dr. Raman Adaikkalavan.

This zip file contains:
The user manual
The developer manual
The result of phases 1-3 as pdf files
One visual paradigm files
SQL scripts used to created the database.
The source code is in the folder Fall2012-TeamBanana-Phase4-VS-SRC.

Visual studio will need to have mvc4 installed to open this Visual Studio solution.


